# Project1
 
1. Make sure you have read the project specification thoroughly.
2. Make sure you had GitHub create a private version of this repository by following the link on BeachBoard. If this repository is called `csulb-cecs475-2020sp/Project1` (without your name at the end), then you are in the wrong place.
3. Clone your repository to your desktop.
4. Implement the project!
5. When ready to test, push your changes to GitHub. View the Commits on your repository and watch for the yellow circle (indicating a build in progress) to turn into a red X (bad) or a green checkmark (good). Click any of the three symbols to see the build and test process in action.
6. Email me with a link to your Commits when you successfully pass the test cases.

Good luck >:).
